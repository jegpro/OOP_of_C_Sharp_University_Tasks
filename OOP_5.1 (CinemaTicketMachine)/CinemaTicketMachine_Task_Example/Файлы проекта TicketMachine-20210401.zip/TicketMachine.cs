﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_ticket
{
    class TicketMachine
    {
        static List<Ticket> legalTickets = new List<Ticket>();

        public Ticket BuyTicket(String movie)
        {
            Ticket t = new Ticket(movie);
            legalTickets.Add(t);
            return t;
        }

        // public bool IsValid(Ticket t)
        bool IsValid(Ticket t)
        {
            foreach (Ticket d in legalTickets)
            {
                if (d.Equals(t))
                    return true;
            }

            return false;
        }

        public void UseTicket(Ticket t)
        {
            if (!IsValid(t))
            {
                Console.WriteLine("ALARM! {0} is not valid!", t);
            }
            else
            {
                Console.WriteLine("Have a nice day!!");
                legalTickets.Remove(t);  //!!!!!!!!!!!!!!!!!!!!!
            }
        }


    }
}
