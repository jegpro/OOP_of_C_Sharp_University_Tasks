﻿using System;


namespace Task_ticket
{
    class Ticket  
    {
        string movie;
        int serialNumber;

        static int nextNumber = 1001;       // !!!  
        /*  Номера билетов уникальны – 
            все билеты, купленные из любого из автомата, имеют различные номера.  
        */ 

        public Ticket(string m)        {
            movie = m;
            serialNumber = nextNumber++;
        }
       
        public override string ToString()
        {
            return String.Format("#Ticket[{0,4}, {1}]", serialNumber, movie);
        }

        public override bool Equals(Object obj)
        {
            if (obj == null) return false;

            if (!(obj is Ticket)) return false;

            Ticket t = (Ticket)obj;    // downcasting
            return this.movie == t.movie && 
                   this.serialNumber == t.serialNumber;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }
}
